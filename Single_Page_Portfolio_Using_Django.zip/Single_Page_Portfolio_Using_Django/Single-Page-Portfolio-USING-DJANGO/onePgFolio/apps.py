from django.apps import AppConfig


class OnepgfolioConfig(AppConfig):
    name = 'onePgFolio'
